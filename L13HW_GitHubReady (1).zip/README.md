# L13 Hash Encryption Homework

This repository contains the password.dat file from the L13 Hash Encryption homework.

## Files Included
- `password.dat` – Pickled file containing the hashed 4-digit password.
- `hash_solve.py` – (Add your Python solution script here)

To run:
```bash
python3 hash_solve.py
```
